//package com.divanstrawberry.musicquizz;
//
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.os.Bundle;
//import android.view.Gravity;
//import android.widget.Button;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//public class QuizActivity extends AppCompatActivity {
//
//    private TextView questionNumberText;
//    private TextView questionText;
//    private Button yesButton;
//    private Button noButton;
//    private Button nextButton;
//    private Button skipQuestionButton;
//
//    private int skippedCount = 0;
//    private int currentQuestionIndex = 0;
//
//    // Вопросы и ответы
//    private String[] questions = {
//            "Оперу Летучий голландец написал Эдуард Вагнер?",
//            "Имя Моцарта — Вольфганг Амадей?",
//            "Гайдн считается одним из классиков эпохи классицизма?",
//            "Бах написал Лунную сонату?",
//            "В опере Кармен главную роль спела Мария Каллас?",
//            "Хоровая музыка называется вокальной музыкой для хора?",
//            "Украшения в музыке XVIII века назывались трелями?",
//            "В опере Девушка с жемчужной серёжкой сюжет основан на историческом событии?",
//            "Партитура — это часть записи музыки для оркестра?",
//            "Симфония №5 написана Людвигом ван Бетховеном?"
//    };
//
//    private boolean[] correctAnswers = {
//            true,
//            true,
//            true,
//            false,
//            false,
//            true,
//            true,
//            false,
//            false,
//            true
//    };
//
//    private SharedPreferences prefs;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_quiz);
//
//        questionNumberText = findViewById(R.id.text_question_number);
//        questionText = findViewById(R.id.text_question);
//        yesButton = findViewById(R.id.button_yes);
//        noButton = findViewById(R.id.button_no);
//        nextButton = findViewById(R.id.button_next);
//        skipQuestionButton = findViewById(R.id.button_skip_question);
//
//        prefs = getSharedPreferences("quiz_stats", MODE_PRIVATE);
//
//        // Сбрасываем счетчики перед игрой
//        prefs.edit().putInt("correct", 0).putInt("wrong", 0).apply();
//        skippedCount = 0;
//
//        loadQuestion();
//
//        yesButton.setOnClickListener(v -> verifyAnswer(true));
//        noButton.setOnClickListener(v -> verifyAnswer(false));
//        nextButton.setOnClickListener(v -> goToNextQuestion());
//        skipQuestionButton.setOnClickListener(v -> skipQuestion());
//
//        hideNextButton();
//    }
//
//    private void loadQuestion() {
//        questionNumberText.setText("Вопрос " + (currentQuestionIndex + 1));
//        questionText.setText(questions[currentQuestionIndex]);
//
//        yesButton.setEnabled(true);
//        noButton.setEnabled(true);
//    }
//
//    private void verifyAnswer(boolean answer) {
//        boolean correct = correctAnswers[currentQuestionIndex];
//        boolean isCorrect = (answer == correct);
//
//        saveResult(isCorrect);
//
//        String msg = isCorrect ? "Ответ верный" : "Ответ не верный";
//
//        Toast toast = Toast.makeText(this, msg, Toast.LENGTH_SHORT);
//        toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 300);
//        toast.show();
//
//        showNextButton();
//
//        yesButton.setEnabled(false);
//        noButton.setEnabled(false);
//    }
//
//    private void saveResult(boolean isCorrect) {
//        int correctCount = prefs.getInt("correct", 0);
//        int wrongCount = prefs.getInt("wrong", 0);
//
//        SharedPreferences.Editor editor = prefs.edit();
//        if (isCorrect) {
//            editor.putInt("correct", correctCount + 1);
//        } else {
//            editor.putInt("wrong", wrongCount + 1);
//        }
//        editor.apply();
//    }
//
//    private void showNextButton() {
//        nextButton.setVisibility(Button.VISIBLE);
//    }
//
//    private void hideNextButton() {
//        nextButton.setVisibility(Button.INVISIBLE);
//    }
//
//    private void goToNextQuestion() {
//        if (currentQuestionIndex >= questions.length - 1) {
//            endQuiz();
//        } else {
//            currentQuestionIndex++;
//            loadQuestion();
//            hideNextButton();
//        }
//    }
//
//    private void skipQuestion() {
//        skippedCount++;
//
//        if (currentQuestionIndex >= questions.length - 1) {
//            endQuiz();
//        } else {
//            currentQuestionIndex++;
//            loadQuestion();
//            hideNextButton();
//
//            yesButton.setEnabled(true);
//            noButton.setEnabled(true);
//        }
//    }
//
//    private void endQuiz() {
//        int correctAnswersCount = prefs.getInt("correct", 0);
//
//        Intent intent = new Intent(this, ResultActivity.class);
//        intent.putExtra(ResultActivity.EXTRA_CORRECT, correctAnswersCount);
//        intent.putExtra(ResultActivity.EXTRA_TOTAL, questions.length);
//        intent.putExtra(ResultActivity.EXTRA_SKIPPED, skippedCount);
//
//        startActivity(intent);
//        finish();
//    }
//}